jQuery.getScript('//js.hsforms.net/forms/v2.js', function(){
    hbspt.forms.create({
        region: "na1",
        portalId: "7934115",
        formId: "f90089a1-d5e2-4370-8932-38bb5e14a251",
        target: ".modal-form-content",
    });
});