// Input fields
const requiredFields = ['q8_firstName', 'q9_lastName', 'q10_email', 'q12_phoneNumber[full]'];
const additionalFields = ['q26_chooseYour', 'q13_haveYou', 'q34_preferredLanguage', 'q37_message'];
const submitButtonSelector = 'body form .form-section .form-submit-button#input_2';

// Hide additional fields and submit button by default
additionalFields.forEach(name => {
    let fieldContainer = document.querySelector(`body form .form-section [name="${name}"]`).closest('li');
    if(fieldContainer){
        fieldContainer.style.display = 'none';
        fieldContainer.style.opacity = '0';
    }
});
let submitButton = document.querySelector(submitButtonSelector);
if(submitButton){
    submitButton.style.opacity = '0';
    submitButton.style.display = 'none';
    submitButton.style.transition = 'opacity 0.5s ease-in-out';
}

// Remove default required attributes
requiredFields.forEach(name => {
    let field = document.querySelector(`body form .form-section [name="${name}"]`);
    if (field) {
        field.removeAttribute('required');
    }
});

// New CONTINUE button
const continueBtnHTML = `<button type="button" class="submit-button form-submit-button contact-continue">CONTINUE</button>`;
const submitButtonContainer = document.querySelector('body form .form-section li #cid_2 button[type="submit"]');

// CONTINUE button functionality for the default input fields
if (!document.querySelector('.contact-continue')) {
    submitButtonContainer.insertAdjacentHTML('afterend', continueBtnHTML);

    const ContinueBtn = document.querySelector('.contact-continue');
    ContinueBtn.addEventListener('click', () => {
        let allFilled = true;
        let firstEmptyField = null;
        
        requiredFields.forEach(name => {
            let field = document.querySelector(`body form .form-section [name="${name}"]`);
            if (field && field.value.trim() === '' && !firstEmptyField) {
                firstEmptyField = field;
            }
        });

        if (firstEmptyField) {
            allFilled = false;
            firstEmptyField.focus();
            firstEmptyField.reportValidity();
        }

        if (allFilled) {
            additionalFields.forEach(name => {
                let fieldContainer = document.querySelector(`body form .form-section [name="${name}"]`).closest('li');
                fieldContainer.style.display = 'block';
                setTimeout(() => {
                    fieldContainer.style.opacity = '1';
                }, 10);
            });
            
            submitButton.style.display = 'block';
            setTimeout(() => {
                submitButton.style.opacity = '1';
            }, 10);
            
            ContinueBtn.style.display = 'none';
            
            // Remove event listener and script once fields are displayed
            ContinueBtn.remove();
        }
    });
}